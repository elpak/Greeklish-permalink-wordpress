<?php // Silence is golden
